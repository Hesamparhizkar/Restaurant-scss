Iran Nastaliq font
================
IranNastaliq.ttf created by [scict.ir](http://scict.ir).

IranNastaliq.ttf is open source font for use Desktop.

This is Modified and optimized version of original font. now you can using in Web/Desktop/Mobile device

Font Developer : Hossein zahedi (http://parsfont.com)

Optimize & WebFont : [Mohammad Saleh Souzanchi](https://github.com/zoghal )



Demo : http://font-store.github.io/font-IranNastaliq/


* * *


?  		      |	   Old Version	 | v1 | v2 |
--------------|--------------|-----|---|
TTF Size  | 1,185kb |   757kb |732kb
Hinted  | No | Yes| Yes
woff | No | 292kb| 298kb
woff2| No |No| 193kb







- - -

